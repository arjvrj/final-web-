<?php
/**
 * popup_event.php — impression and click counters for the promotion popups.
 *
 * POST only, JSON only, called by assets/js/popup.js from a marketing page.
 *
 * Why it exists separately: the popup itself is rendered with the page, but a
 * page view is not an impression — a visitor who never saw the popup (closed the
 * tab, or the trigger never fired) must not be counted. The browser reports what
 * actually happened.
 *
 * What keeps the numbers honest:
 *   - the CSRF token every public page already carries;
 *   - a same-origin check, so another site cannot inflate a campaign;
 *   - `id` must be an integer and `kind` must be impression or click;
 *   - one impression and one click per campaign per PHP session, so a reload or a
 *     double-fire cannot multiply the count;
 *   - the campaign must exist and be reachable by the current rules.
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/security.php';
require_once __DIR__ . '/includes/popups.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

function rg_popup_event_reply(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    rg_popup_event_reply(['ok' => false, 'error' => 'Method not allowed'], 405);
}

/* Same origin only. A missing Origin and Referer is allowed (some privacy
   browsers strip both), but a header that names another site is refused. */
$host = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
foreach (['HTTP_ORIGIN', 'HTTP_REFERER'] as $header) {
    $value = (string)($_SERVER[$header] ?? '');
    if ($value === '') continue;
    $valueHost = strtolower((string)parse_url($value, PHP_URL_HOST));
    if ($valueHost !== '' && $host !== '' && $valueHost !== $host) {
        rg_popup_event_reply(['ok' => false, 'error' => 'Cross-site request refused'], 403);
    }
}

requireCsrf();

$id   = (int)($_POST['id'] ?? 0);
$kind = (string)($_POST['kind'] ?? '');

if ($id <= 0 || !in_array($kind, ['impression', 'click'], true)) {
    rg_popup_event_reply(['ok' => false, 'error' => 'Unknown event'], 422);
}

$popup = rg_popup_find($id);
if (!$popup) {
    rg_popup_event_reply(['ok' => false, 'error' => 'Unknown campaign'], 404);
}

/* Only a campaign a visitor could actually have seen is counted. */
if (rg_popup_status($popup) !== 'active') {
    rg_popup_event_reply(['ok' => false, 'error' => 'Campaign is not live'], 409);
}

rg_start_session();
if (!isset($_SESSION['rg_popup_counted']) || !is_array($_SESSION['rg_popup_counted'])) {
    $_SESSION['rg_popup_counted'] = [];
}
$seen = $_SESSION['rg_popup_counted'][$id] ?? [];
if (!is_array($seen)) $seen = [];

if (!empty($seen[$kind])) {
    /* Already counted for this visitor: answer success, change nothing. */
    rg_popup_event_reply(['ok' => true, 'counted' => false]);
}

$column = $kind === 'click' ? 'clicks' : 'impressions';
try {
    $stmt = $conn->prepare("UPDATE popups SET {$column} = {$column} + 1 WHERE id = ?");
    $stmt->execute([$id]);
} catch (Exception $e) {
    error_log('popup event failed: ' . $e->getMessage());
    rg_popup_event_reply(['ok' => false, 'error' => 'Could not record the event'], 500);
}

$seen[$kind] = time();
$_SESSION['rg_popup_counted'][$id] = $seen;

rg_popup_event_reply(['ok' => true, 'counted' => true]);
