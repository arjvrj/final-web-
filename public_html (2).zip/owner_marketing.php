<?php
/**
 * owner_marketing.php — Owner panel: Marketing → Popup & Promotions
 * URL:   owner_marketing.php                     the campaign list
 *        owner_marketing.php?action=new          the editor, empty
 *        owner_marketing.php?action=edit&id=N    the editor, filled
 *        owner_marketing.php?action=preview&id=N the popup on its own page
 * POST:  action=save | toggle | delete
 *
 * Uploads go through the same storage as the rest of the app (assets/uploads),
 * with the same rules: the file must really be an image, the extension comes from
 * the detected type, and the name on disk is random.
 *
 * Owner only, and every POST is CSRF-checked through the form token.
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/popups.php';

requireOwner();

$notice = '';
$errors = [];

/* =========================================================
   ACTIONS
   ========================================================= */
$action = (string)($_POST['action'] ?? $_GET['action'] ?? '');

if ($action === 'save' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    requireCsrf();

    $id = (int)($_POST['id'] ?? 0);
    $storedImage = '';
    $removeImage = !empty($_POST['remove_image']);
    $imageError = '';

    if (!empty($_FILES['image']['tmp_name']) && is_uploaded_file($_FILES['image']['tmp_name'])) {
        $check = rg_popup_validate_image(
            (string)$_FILES['image']['tmp_name'],
            (int)($_FILES['image']['size'] ?? 0)
        );
        if (!$check['ok']) {
            $imageError = $check['error'];
        } else {
            $dir = __DIR__ . '/assets/uploads';
            if (!is_dir($dir)) @mkdir($dir, 0755, true);
            $fname = rg_popup_image_name($check['ext']);
            if (move_uploaded_file($_FILES['image']['tmp_name'], $dir . '/' . $fname)) {
                @chmod($dir . '/' . $fname, 0644);
                $storedImage = 'assets/uploads/' . $fname;
            } else {
                $imageError = 'The image could not be saved. Check the uploads folder permissions.';
            }
        }
    } elseif (!empty($_FILES['image']['name'])) {
        $code = (int)($_FILES['image']['error'] ?? 0);
        if ($code === UPLOAD_ERR_INI_SIZE || $code === UPLOAD_ERR_FORM_SIZE) {
            $imageError = 'That image is larger than this server accepts. Use something under 4 MB.';
        } elseif ($code !== UPLOAD_ERR_NO_FILE) {
            $imageError = 'The image upload failed. Please try again.';
        }
    }

    /* The form offers checkboxes; rg_popup_save() takes one comma list, so the
       choice is folded here. "All pages" wins if both were somehow sent. */
    if (!empty($_POST['target_all'])) {
        $_POST['targets'] = 'all';
    } else {
        $picked = array_map('strval', (array)($_POST['target_page'] ?? []));
        $_POST['targets'] = implode(',', $picked);
    }

    $result = rg_popup_save($_POST, $id, $storedImage, $removeImage);

    if ($imageError !== '') {
        $result['ok'] = false;
        $result['errors']['image'] = $imageError;
        if ($storedImage !== '') rg_popup_delete_file($storedImage);
    }

    if (!$result['ok']) {
        $errors = $result['errors'];
        $action = $id > 0 ? 'edit' : 'new';
        $_GET['id'] = (string)$id;
    } else {
        /* A replaced image should not leave the old file behind. */
        if ($storedImage !== '' && $id > 0) {
            $previous = rg_popup_image_from_db($id);
            if ($previous !== '' && $previous !== $storedImage) rg_popup_delete_file($previous);
        }
        $_SESSION['marketing_notice'] = $id > 0
            ? 'Campaign saved.'
            : 'Campaign created. Publish it when you are ready.';
        header('Location: owner_marketing.php?action=edit&id=' . (int)$result['id']);
        exit;
    }
}

if ($action === 'toggle' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    requireCsrf();
    $id = (int)($_POST['id'] ?? 0);
    $to = (string)($_POST['to'] ?? '');
    if ($id > 0 && rg_popup_set_status($id, $to)) {
        $_SESSION['marketing_notice'] = $to === 'active'
            ? 'Campaign published. It follows its schedule and page targeting.'
            : 'Campaign disabled. Visitors will not see it.';
    } else {
        $_SESSION['marketing_notice'] = 'That change could not be saved.';
    }
    header('Location: owner_marketing.php');
    exit;
}

if ($action === 'delete' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    requireCsrf();
    $id = (int)($_POST['id'] ?? 0);
    $_SESSION['marketing_notice'] = ($id > 0 && rg_popup_delete($id))
        ? 'Campaign deleted, and its image removed from the server.'
        : 'That campaign could not be deleted.';
    header('Location: owner_marketing.php');
    exit;
}

if (!empty($_SESSION['marketing_notice'])) {
    $notice = (string)$_SESSION['marketing_notice'];
    unset($_SESSION['marketing_notice']);
}

$page = 'marketing';
$csrffield = csrfField();

/* =========================================================
   PREVIEW — the popup on its own page, owner only
   ========================================================= */
if ($action === 'preview') {
    $popup = rg_popup_find((int)($_GET['id'] ?? 0));
    if (!$popup) {
        header('Location: owner_marketing.php');
        exit;
    }
    $appName = getSetting('app_name', 'ReviewAI');
    $targets = (string)($popup['targets'] ?? '');
    $pages = rg_popup_page_registry();
    $pageLabel = [];
    foreach (explode(',', $targets) as $key) {
        if ($key === 'all') { $pageLabel[] = 'all public marketing pages'; continue; }
        if (isset($pages[$key])) $pageLabel[] = $pages[$key]['label'];
    }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="robots" content="noindex,nofollow">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Preview · <?= e($popup['name']) ?> · <?= e($appName) ?></title>
<link rel="stylesheet" href="<?= e(asset('css/fonts.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('css/public.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('css/popup.css')) ?>">
<style>
  body { min-height: 100vh; }
  .preview-note {
    position: fixed; left: 50%; bottom: 14px; transform: translateX(-50%);
    z-index: 2147483001; max-width: calc(100% - 28px);
    background: #141623; color: #FFFDFB; border-radius: 999px;
    font: 600 12px/1.4 Inter, system-ui, sans-serif; letter-spacing: .01em;
    padding: 9px 16px; text-align: center; opacity: .92;
  }
</style>
</head>
<body>
<div class="preview-note">
  Preview of “<?= e($popup['name']) ?>” · shows on <?= e(implode(', ', $pageLabel) ?: 'no page yet') ?> ·
  <?= e(rg_popup_status_label(rg_popup_status($popup))) ?>
</div>
<?php rg_popup_render($popup, 'preview'); ?>
<script src="<?= e(asset('js/popup.js')) ?>"></script>
<script>
  /* The public page lets the trigger and the visitor's own memory decide. A
     preview must show it immediately, or the owner is looking at nothing. */
  document.addEventListener('DOMContentLoaded', function () {
    var root = document.getElementById('rgPopup');
    if (!root) return;
    root.hidden = false;
    document.body.classList.add('rg-pop-open');
  });
</script>
</body>
</html>
    <?php
    exit;
}

/* =========================================================
   RENDER
   ========================================================= */
$rows  = rg_popup_all();
$stats = rg_popup_stats($rows);

$editing = null;
$editingId = (int)($_GET['id'] ?? 0);
if ($action === 'edit' && $editingId > 0) {
    $editing = rg_popup_find($editingId);
}
$showEditor = $action === 'new' || $editing !== null;

/* Values for the editor: the posted attempt if there was one, otherwise the row. */
$v = [
    'id' => 0, 'name' => '', 'status' => 'draft', 'layout' => 'image_text', 'image' => '',
    'heading' => '', 'description' => '', 'coupon_code' => '', 'cta_enabled' => 1,
    'cta_text' => 'Claim offer', 'cta_url' => '', 'cta_new_tab' => 1,
    'trigger_type' => 'delay', 'trigger_value' => 3, 'frequency' => 'session',
    'targets' => 'home', 'starts_at' => '', 'ends_at' => '',
];
if ($editing) {
    $v = array_merge($v, array_map(static function ($value) {
        return $value === null ? '' : $value;
    }, $editing));
} elseif ($errors) {
    /* Keep what was typed so nothing has to be re-entered. */
    foreach (['name','status','layout','heading','description','coupon_code','cta_text','cta_url','trigger_type','trigger_value','frequency','targets'] as $key) {
        if (isset($_POST[$key])) $v[$key] = (string)$_POST[$key];
    }
    $v['id'] = (int)($_POST['id'] ?? 0);
    $v['cta_enabled'] = !empty($_POST['cta_enabled']) ? 1 : 0;
    $v['cta_new_tab'] = !empty($_POST['cta_new_tab']) ? 1 : 0;
    $v['starts_at'] = (string)($_POST['starts_at'] ?? '');
    $v['ends_at']   = (string)($_POST['ends_at'] ?? '');
}

$imageUrl = rg_popup_image_url((string)$v['image']);
$targets  = array_filter(explode(',', (string)$v['targets']));
$previewUrl = $v['id'] > 0 ? 'owner_marketing.php?action=preview&id=' . (int)$v['id'] : '';

ob_start();
?>

<h1>Popup &amp; promotions</h1>
<p>Announce a sale, a new feature or a coupon on your marketing pages. Create it here, upload your artwork, publish — no code and no redeploy.</p>

<?php if ($notice !== ''): ?>
<div class="alert" role="status"><?= e($notice) ?></div>
<?php endif; ?>

<div class="stack" style="gap:.8rem;flex-wrap:wrap;margin:1rem 0">
    <div class="card" style="flex:1 1 150px;margin:0">
        <h2 style="margin:0 0 .25rem"><?= (int)$stats['total'] ?></h2>
        <p class="muted" style="margin:0">Total campaigns</p>
    </div>
    <div class="card" style="flex:1 1 150px;margin:0">
        <h2 style="margin:0 0 .25rem"><?= (int)$stats['active'] ?></h2>
        <p class="muted" style="margin:0">Active now</p>
    </div>
    <div class="card" style="flex:1 1 150px;margin:0">
        <h2 style="margin:0 0 .25rem"><?= (int)$stats['scheduled'] ?></h2>
        <p class="muted" style="margin:0">Scheduled</p>
    </div>
    <div class="card" style="flex:1 1 150px;margin:0">
        <h2 style="margin:0 0 .25rem"><?= (int)$stats['expired'] ?></h2>
        <p class="muted" style="margin:0">Expired</p>
    </div>
    <div class="card" style="flex:1 1 150px;margin:0">
        <h2 style="margin:0 0 .25rem"><?= (int)$stats['impressions'] ?> / <?= (int)$stats['clicks'] ?></h2>
        <p class="muted" style="margin:0">Impressions / clicks</p>
    </div>
</div>

<p>
    <a class="btn" href="owner_marketing.php?action=new">+ Create New Popup</a>
</p>

<?php if (!$rows): ?>
<div class="card">
    <h2>No campaigns yet</h2>
    <p class="muted">Create your first popup: upload an image, add a heading and a coupon, choose when it should appear, then publish it.</p>
</div>
<?php else: ?>
<div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Campaign</th><th>Status</th><th>Starts</th><th>Ends</th>
                <th>Impressions</th><th>Clicks</th><th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $row):
            $state = rg_popup_status($row);
            $thumb = rg_popup_image_url((string)($row['image'] ?? ''));
        ?>
            <tr>
                <td>
                    <div class="stack" style="gap:.6rem;align-items:center">
                        <?php if ($thumb !== ''): ?>
                        <img src="<?= e($thumb) ?>" alt="" width="44" height="44"
                             style="width:44px;height:44px;object-fit:cover;border-radius:10px;border:1px solid #dfe4e0">
                        <?php else: ?>
                        <span class="tag" style="width:44px;height:44px;display:grid;place-items:center;border-radius:10px">—</span>
                        <?php endif; ?>
                        <strong><?= e($row['name']) ?></strong>
                    </div>
                </td>
                <td>
                    <span class="tag" style="background:<?=
                        $state === 'active' ? '#e6f4e9' : ($state === 'scheduled' ? '#fdf3dc' : ($state === 'expired' ? '#f1f2f4' : '#eef1f7'))
                    ?>;color:<?=
                        $state === 'active' ? '#1f513b' : ($state === 'scheduled' ? '#6b4e14' : '#4a4f57')
                    ?>"><?= e(rg_popup_status_label($state)) ?></span>
                </td>
                <td><?= e($row['starts_at'] ? date('d M Y', strtotime((string)$row['starts_at'])) : 'Immediately') ?></td>
                <td><?= e($row['ends_at'] ? date('d M Y', strtotime((string)$row['ends_at'])) : 'No end date') ?></td>
                <td><?= (int)$row['impressions'] ?></td>
                <td><?= (int)$row['clicks'] ?></td>
                <td>
                    <div class="stack" style="gap:.35rem;flex-wrap:wrap">
                        <a class="btn" href="owner_marketing.php?action=edit&amp;id=<?= (int)$row['id'] ?>">Edit</a>
                        <a class="btn" href="owner_marketing.php?action=preview&amp;id=<?= (int)$row['id'] ?>"
                           target="_blank" rel="noopener">Preview</a>

                        <form method="post" action="owner_marketing.php" style="display:inline">
                            <?= $csrffield ?>
                            <input type="hidden" name="action" value="toggle">
                            <input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
                            <?php if ($state === 'active'): ?>
                            <input type="hidden" name="to" value="paused">
                            <button class="btn" type="submit">Disable</button>
                            <?php else: ?>
                            <input type="hidden" name="to" value="active">
                            <button class="btn" type="submit">Enable</button>
                            <?php endif; ?>
                        </form>

                        <form method="post" action="owner_marketing.php" style="display:inline"
                              onsubmit="return confirm('Delete this campaign and its image? This cannot be undone.');">
                            <?= $csrffield ?>
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
                            <button class="btn" type="submit" style="border-color:#b23b3b;color:#b23b3b">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php if ($showEditor): ?>
<form id="popupForm" method="post" action="owner_marketing.php" enctype="multipart/form-data" style="margin-top:1.5rem">
    <?= $csrffield ?>
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= (int)$v['id'] ?>">

    <div class="card">
        <div class="stack" style="justify-content:space-between;align-items:flex-start">
            <h2 style="margin:0"><?= $v['id'] > 0 ? 'Edit campaign' : 'Create popup' ?></h2>
            <?php if ($previewUrl !== ''): ?>
            <a class="btn" href="<?= e($previewUrl) ?>" target="_blank" rel="noopener">Preview ↗</a>
            <?php endif; ?>
        </div>

        <?php if ($errors): ?>
        <div class="alert" role="alert" style="background:#fdecec;color:#8a2020;margin-top:1rem">
            <?= e(implode(' ', $errors)) ?>
        </div>
        <?php endif; ?>

        <div class="field" style="margin-top:1rem">
            <label for="name">Campaign name *</label>
            <input id="name" name="name" type="text" required maxlength="120"
                   value="<?= e($v['name']) ?>" placeholder="Diwali 2026 Special Offer">
            <p class="muted" style="margin:.4rem 0 0;font-size:.85rem">Only shown in this panel.</p>
        </div>

        <div class="field">
            <label for="image">Popup image *</label>
            <input id="image" name="image" type="file" accept="image/jpeg,image/png,image/webp">
            <p class="muted" style="margin:.4rem 0 0;font-size:.85rem">
                JPG, PNG or WebP, up to 4 MB, at least 320 px on each side. 4:5 or 1:1 works best.
                The artwork is shown whole — never cropped or stretched.
            </p>

            <?php if ($imageUrl !== ''): ?>
            <div style="margin-top:.8rem">
                <img id="imagePreview" src="<?= e($imageUrl) ?>" alt="Current popup image"
                     style="width:100%;max-width:260px;border-radius:14px;border:1px solid #dfe4e0;display:block">
                <label class="stack" style="gap:.45rem;margin-top:.6rem;font-size:.9rem;align-items:center">
                    <input type="checkbox" name="remove_image" value="1" style="width:auto">
                    Remove this image
                </label>
            </div>
            <?php else: ?>
            <img id="imagePreview" alt="" hidden style="width:100%;max-width:260px;border-radius:14px;border:1px solid #dfe4e0;margin-top:.8rem">
            <?php endif; ?>
        </div>

        <div class="field">
            <label for="layout">Popup layout</label>
            <select id="layout" name="layout">
                <?php foreach (rg_popup_layouts() as $key => $label): ?>
                <option value="<?= e($key) ?>" <?= $v['layout'] === $key ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="field">
            <label for="heading">Popup heading</label>
            <input id="heading" name="heading" type="text" maxlength="160" value="<?= e($v['heading']) ?>"
                   placeholder="Diwali Sale — 30% off all plans">
        </div>

        <div class="field">
            <label for="description">Popup description</label>
            <textarea id="description" name="description" rows="2" maxlength="400"
                      placeholder="Use code REVIEW30 at checkout. Offer ends 12 November."><?= e($v['description']) ?></textarea>
        </div>

        <div class="field">
            <label for="coupon_code">Coupon code (optional)</label>
            <input id="coupon_code" name="coupon_code" type="text" maxlength="40" value="<?= e($v['coupon_code']) ?>"
                   placeholder="REVIEW30" style="text-transform:uppercase">
            <p class="muted" style="margin:.4rem 0 0;font-size:.85rem">
                Shown with a Copy button. Letters, numbers, hyphen and underscore only.
            </p>
        </div>

        <div class="field">
            <label class="stack" style="gap:.5rem;align-items:center;font-size:.95rem">
                <input type="checkbox" name="cta_enabled" value="1" style="width:auto"
                       <?= (int)$v['cta_enabled'] === 1 ? 'checked' : '' ?>>
                Show a call-to-action button
            </label>
        </div>

        <div class="field">
            <label for="cta_text">Button text</label>
            <input id="cta_text" name="cta_text" type="text" maxlength="60" value="<?= e($v['cta_text']) ?>"
                   placeholder="Claim offer">
        </div>

        <div class="field">
            <label for="cta_url">Button destination</label>
            <input id="cta_url" name="cta_url" type="text" inputmode="url" maxlength="500"
                   value="<?= e($v['cta_url']) ?>" placeholder="https://yoursite.com/pricing">
            <p class="muted" style="margin:.4rem 0 0;font-size:.85rem">
                A full web address, or a path on this site such as signup.php.
            </p>
        </div>

        <div class="field">
            <label class="stack" style="gap:.5rem;align-items:center;font-size:.95rem">
                <input type="checkbox" name="cta_new_tab" value="1" style="width:auto"
                       <?= (int)$v['cta_new_tab'] === 1 ? 'checked' : '' ?>>
                Open the button in a new tab
            </label>
        </div>
    </div>

    <div class="card">
        <h2>When and where</h2>

        <div class="field" style="margin-top:1rem">
            <label for="trigger_type">Trigger</label>
            <select id="trigger_type" name="trigger_type">
                <?php foreach (rg_popup_triggers() as $key => $label): ?>
                <option value="<?= e($key) ?>" <?= $v['trigger_type'] === $key ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="field">
            <label for="trigger_value">Delay (seconds) or scroll depth (percent)</label>
            <input id="trigger_value" name="trigger_value" type="number" min="1" max="60"
                   value="<?= (int)$v['trigger_value'] ?>">
            <p class="muted" style="margin:.4rem 0 0;font-size:.85rem">
                Delay uses seconds (3–5 is usual); scroll uses a percentage of the page (30–60).
                Exit intent ignores this and is desktop only.
            </p>
        </div>

        <div class="field">
            <label for="frequency">How often a visitor sees it</label>
            <select id="frequency" name="frequency">
                <?php foreach (rg_popup_frequencies() as $key => $label): ?>
                <option value="<?= e($key) ?>" <?= $v['frequency'] === $key ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="field">
            <label>Pages</label>
            <?php foreach (rg_popup_page_registry() as $key => $meta): ?>
            <label class="stack" style="gap:.5rem;align-items:center;font-size:.95rem;font-weight:400">
                <input type="checkbox" name="target_page[]" value="<?= e($key) ?>" style="width:auto"
                       <?= in_array($key, $targets, true) ? 'checked' : '' ?>>
                <?= e($meta['label']) ?>
            </label>
            <?php endforeach; ?>
            <label class="stack" style="gap:.5rem;align-items:center;font-size:.95rem;font-weight:400">
                <input type="checkbox" name="target_all" value="all" style="width:auto"
                       <?= in_array('all', $targets, true) ? 'checked' : '' ?>>
                All public marketing pages
            </label>
            <p class="muted" style="margin:.5rem 0 0;font-size:.85rem">
                Promotions never appear in a business dashboard, the owner panel, or the customer
                QR and review flow — those pages do not load the popup at all.
            </p>
        </div>

        <div class="field">
            <label for="starts_at">Start date (optional)</label>
            <input id="starts_at" name="starts_at" type="date"
                   value="<?= e($v['starts_at'] !== '' ? substr((string)$v['starts_at'], 0, 10) : '') ?>">
        </div>

        <div class="field">
            <label for="ends_at">End date (optional)</label>
            <input id="ends_at" name="ends_at" type="date"
                   value="<?= e($v['ends_at'] !== '' ? substr((string)$v['ends_at'], 0, 10) : '') ?>">
            <p class="muted" style="margin:.4rem 0 0;font-size:.85rem">
                The campaign stops showing by itself after this date. Leave both dates empty to run until you disable it.
            </p>
        </div>

        <div class="field">
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="draft"  <?= $v['status'] === 'draft'  ? 'selected' : '' ?>>Draft — not shown</option>
                <option value="active" <?= $v['status'] === 'active' ? 'selected' : '' ?>>Published — follows the schedule</option>
                <option value="paused" <?= $v['status'] === 'paused' ? 'selected' : '' ?>>Disabled — kept, not shown</option>
            </select>
        </div>

        <div class="stack" style="gap:.6rem;margin-top:1rem;flex-wrap:wrap">
            <button class="btn" type="submit"><?= $v['id'] > 0 ? 'Save changes' : 'Create popup' ?></button>
            <a class="btn" href="owner_marketing.php">Back to list</a>
        </div>
    </div>
</form>

<script>
/* Show the picked image before it is uploaded, and refresh the preview src. */
(function () {
    var input = document.getElementById('image');
    var preview = document.getElementById('imagePreview');
    if (!input || !preview) return;
    input.addEventListener('change', function () {
        var file = input.files && input.files[0];
        if (!file) return;
        preview.src = URL.createObjectURL(file);
        preview.hidden = false;
    });
})();

/* The page checkboxes and "all pages" are one choice: ticking one clears the
   other, so a campaign can never target everything by accident. */
(function () {
    var all = document.querySelector('input[name="target_all"]');
    var singles = Array.prototype.slice.call(document.querySelectorAll('input[name="target_page[]"]'));
    if (!all) return;
    all.addEventListener('change', function () {
        if (all.checked) singles.forEach(function (box) { box.checked = false; });
    });
    singles.forEach(function (box) {
        box.addEventListener('change', function () {
            if (box.checked) all.checked = false;
        });
    });
})();
</script>
<?php endif; ?>

<?php
$content = ob_get_clean();
require_once __DIR__ . '/includes/owner_layout.php';
