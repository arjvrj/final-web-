<?php
/**
 * popups.php — the Popup & Promotion Manager, and every rule about it.
 *
 * Used by:
 *   - app/owner_marketing.php   (the Marketing → Popup & Promotions screen)
 *   - app/home.php, login.php, signup.php  (the public pages that may show one)
 *   - app/popup_event.php       (impression / click counting)
 *
 * The rules of the house:
 *   - **Marketing pages only.** A popup can never appear in a business dashboard,
 *     the owner panel, or the customer review/QR flow. Those pages simply do not
 *     call this file — the exclusion is structural, not a setting.
 *   - **Only a stored image, never pasted HTML.** The admin can upload an image
 *     and type text; the popup markup is built here.
 *   - **The browser is not trusted with the schedule.** Which campaign is live is
 *     decided in SQL (status + date window) and then matched against the page.
 *   - **Frequency is the visitor's memory, not ours.** No row is written when
 *     someone sees or closes a popup; the browser remembers, and the counters
 *     only move once per visitor per campaign.
 */

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/links.php';

/* ------------------------------------------------------------------ limits */

const RG_POPUP_NAME_MAX  = 120;
const RG_POPUP_HEAD_MAX  = 160;
const RG_POPUP_DESC_MAX  = 400;
const RG_POPUP_CTA_MAX   = 60;
const RG_POPUP_COUPON_MAX = 40;

/** Upload limit for a promotional image. */
const RG_POPUP_IMAGE_MAX_BYTES = 4 * 1024 * 1024;

/** Aspect ratios a popup image may use: 4:5 (portrait) and 1:1 (square). */
const RG_POPUP_IMAGE_MIN_SIDE = 320;
const RG_POPUP_IMAGE_MAX_SIDE = 4000;

/* --------------------------------------------------------------- registry */

/**
 * The public marketing pages a popup may target.
 *
 * Deliberately short and explicit. Dashboards, the owner panel and review.php are
 * not in this list, so there is no setting anywhere that can put a promotion in
 * front of a customer who is writing a review.
 */
function rg_popup_page_registry(): array
{
    return [
        'home'    => ['label' => 'Homepage', 'path' => '/'],
        'pricing' => ['label' => 'Pricing section (homepage #pricing)', 'path' => '/#pricing'],
        'login'   => ['label' => 'Log in page', 'path' => '/login.php'],
        'signup'  => ['label' => 'Sign-up page', 'path' => '/signup.php'],
    ];
}

function rg_popup_layouts(): array
{
    return [
        'image'        => 'Image only — the artwork fills the popup',
        'image_text'   => 'Image + heading and description',
        'image_cta'    => 'Image + call-to-action button',
        'announcement' => 'Promotional announcement (text first)',
    ];
}

function rg_popup_triggers(): array
{
    return [
        'immediate' => 'Immediately after the page loads',
        'delay'     => 'After a delay',
        'scroll'    => 'After the visitor scrolls a set distance',
        'exit'      => 'Exit intent (desktop only)',
    ];
}

function rg_popup_frequencies(): array
{
    return [
        'always'   => 'Every visit',
        'session'  => 'Once per browser session',
        '24h'      => 'Once every 24 hours',
        '7d'       => 'Once every 7 days',
        'campaign' => 'Once per campaign, ever',
    ];
}

/* ---------------------------------------------------------------- the page */

/**
 * Which registry key is rendering right now?
 *
 * Set explicitly by each page (`print_rg_popup('home')`), so there is no guesswork
 * from the URL: a rewrite or a query string cannot make a popup appear on a page
 * that did not ask for one.
 */
function rg_popup_current_page(): string
{
    return defined('RG_PUBLIC_PAGE') ? (string)RG_PUBLIC_PAGE : '';
}

/* -------------------------------------------------------------- validation */

/** Trims, strips control characters and caps a single line of text. */
function rg_popup_line(string $value, int $max): string
{
    $value = trim(preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $value));
    if (function_exists('mb_substr')) return mb_substr($value, 0, $max);
    return substr($value, 0, $max);
}

/**
 * A coupon code: letters, digits, hyphen and underscore only.
 *
 * Anything else could not be typed or copied reliably, and there is no reason a
 * code needs a `<` in it.
 */
function rg_popup_coupon(string $value): string
{
    $value = strtoupper(trim($value));
    $value = preg_replace('/[^A-Z0-9_-]/', '', $value);
    return substr($value, 0, RG_POPUP_COUPON_MAX);
}

/** A page target list: known keys only, always at least one. */
function rg_popup_targets(string $raw): string
{
    $known = array_keys(rg_popup_page_registry());
    $parts = array_filter(array_map('trim', explode(',', strtolower($raw))));
    $out = [];
    foreach ($parts as $part) {
        if ($part === 'all') return 'all';
        if (in_array($part, $known, true) && !in_array($part, $out, true)) $out[] = $part;
    }
    return $out ? implode(',', $out) : 'home';
}

function rg_popup_targets_match(string $targets, string $page): bool
{
    if ($page === '') return false;

    /* "all" means all *marketing* pages. A page that is not in the registry —
       a dashboard, the owner panel, the customer review flow — matches nothing,
       whatever the database says. The exclusion cannot be edited away. */
    if (!array_key_exists($page, rg_popup_page_registry())) return false;

    foreach (array_map('trim', explode(',', $targets)) as $target) {
        if ($target === 'all' || $target === $page) return true;
    }
    return false;
}

/* ------------------------------------------------------------ status logic */

/**
 * The state a campaign is in *right now*.
 *
 * draft / paused are the owner's own switches. For an active campaign the dates
 * decide: before the start it is scheduled, after the end it is expired, and
 * between the two it is live.
 */
function rg_popup_status(array $row, ?int $now = null): string
{
    $now = $now ?? time();
    $status = strtolower((string)($row['status'] ?? 'draft'));
    if ($status === 'draft') return 'draft';
    if ($status === 'paused') return 'paused';

    $starts = !empty($row['starts_at']) ? strtotime((string)$row['starts_at']) : null;
    $ends   = !empty($row['ends_at']) ? strtotime((string)$row['ends_at']) : null;

    /* A date the owner typed but PHP cannot read is treated as "no date": the
       campaign stays live rather than silently disappearing. */
    if ($starts !== false && $starts !== null && $now < $starts) return 'scheduled';
    if ($ends !== false && $ends !== null && $now > $ends) return 'expired';
    return 'active';
}

function rg_popup_status_label(string $status): string
{
    return [
        'active'    => 'Active',
        'scheduled' => 'Scheduled',
        'expired'   => 'Expired',
        'paused'    => 'Disabled',
        'draft'     => 'Draft',
    ][$status] ?? 'Draft';
}

/** The date a `<input type="date">` sends → a MySQL DATETIME, or null. */
function rg_popup_date(?string $value, string $time = '00:00:00'): ?string
{
    $value = trim((string)$value);
    if ($value === '') return null;
    $parsed = DateTime::createFromFormat('Y-m-d H:i:s', $value . ' ' . $time);
    if (!$parsed) {
        $parsed = DateTime::createFromFormat('Y-m-d', $value);
        if (!$parsed) return null;
        $parsed->setTime(0, 0, 0);
    }
    return $parsed->format('Y-m-d H:i:s');
}

/* ------------------------------------------------------------------ images */

/**
 * Checks an uploaded popup image.
 *
 * Returns ['ok', 'ext', 'width', 'height', 'error']. The extension comes from the
 * detected type, never from the file name; the dimensions are checked because a
 * 40-pixel-wide image in a popup looks broken on every device.
 */
function rg_popup_validate_image(string $tmpPath, int $size): array
{
    if ($tmpPath === '' || !is_file($tmpPath)) {
        return ['ok' => false, 'ext' => '', 'error' => 'No image was uploaded.', 'width' => 0, 'height' => 0];
    }
    if ($size <= 0) {
        return ['ok' => false, 'ext' => '', 'error' => 'The image is empty.', 'width' => 0, 'height' => 0];
    }
    if ($size > RG_POPUP_IMAGE_MAX_BYTES) {
        return ['ok' => false, 'ext' => '', 'error' => 'The image must be 4 MB or smaller.', 'width' => 0, 'height' => 0];
    }

    $info = @getimagesize($tmpPath);
    $allowed = [
        IMAGETYPE_JPEG => 'jpg',
        IMAGETYPE_PNG  => 'png',
        IMAGETYPE_WEBP => 'webp',
        IMAGETYPE_GIF  => 'gif',
    ];
    $ext = ($info && isset($allowed[$info[2]])) ? $allowed[$info[2]] : '';
    if ($ext === '') {
        return ['ok' => false, 'ext' => '', 'error' => 'Use a JPG, PNG or WebP image.', 'width' => 0, 'height' => 0];
    }

    $width  = (int)$info[0];
    $height = (int)$info[1];
    if ($width < RG_POPUP_IMAGE_MIN_SIDE || $height < RG_POPUP_IMAGE_MIN_SIDE) {
        return ['ok' => false, 'ext' => '', 'error' => 'The image is too small. Use at least '
            . RG_POPUP_IMAGE_MIN_SIDE . '×' . RG_POPUP_IMAGE_MIN_SIDE . ' pixels.', 'width' => $width, 'height' => $height];
    }
    if ($width > RG_POPUP_IMAGE_MAX_SIDE || $height > RG_POPUP_IMAGE_MAX_SIDE) {
        return ['ok' => false, 'ext' => '', 'error' => 'The image is larger than '
            . RG_POPUP_IMAGE_MAX_SIDE . ' pixels on a side. Please scale it down.', 'width' => $width, 'height' => $height];
    }

    /* 4:5 → 2:1 in either orientation. Outside that the popup would either crop
       the artwork or leave a band of empty space, and the brief is explicit:
       do not crop or distort what the owner uploaded. */
    $ratio = $width / max(1, $height);
    if ($ratio < 0.5 || $ratio > 2.0) {
        return ['ok' => false, 'ext' => '', 'error' => 'That shape cannot be shown without cropping it. '
            . 'Use something between 1:2 and 2:1 — 4:5 or 1:1 is ideal.', 'width' => $width, 'height' => $height];
    }

    return ['ok' => true, 'ext' => $ext, 'error' => '', 'width' => $width, 'height' => $height];
}

function rg_popup_image_name(string $ext): string
{
    $allowed = ['jpg', 'png', 'webp', 'gif'];
    if (!in_array($ext, $allowed, true)) $ext = 'jpg';
    return 'popup-' . bin2hex(random_bytes(8)) . '.' . $ext;
}

/** A stored path is used only if it is inside uploads and the file is there. */
function rg_popup_image_url(string $path): string
{
    if ($path === '') return '';
    if (preg_match('#^assets/uploads/[A-Za-z0-9._-]+$#', $path) !== 1) return '';
    if (!is_file(__DIR__ . '/../' . $path)) return '';
    return url($path);
}

/* -------------------------------------------------------------- save/delete */

/**
 * Validates and stores a campaign.
 *
 * Returns ['ok', 'id', 'errors' => [field => message]]. Nothing is written when
 * any field fails, so a campaign never half-exists.
 */
function rg_popup_save(array $input, int $id = 0, string $newImage = '', bool $removeImage = false): array
{
    $errors = [];

    $name = rg_popup_line((string)($input['name'] ?? ''), RG_POPUP_NAME_MAX);
    if ($name === '') $errors['name'] = 'Give the campaign a name. It is only used in this panel.';

    $layout = strtolower(trim((string)($input['layout'] ?? 'image_text')));
    if (!array_key_exists($layout, rg_popup_layouts())) $layout = 'image_text';

    $heading     = rg_popup_line((string)($input['heading'] ?? ''), RG_POPUP_HEAD_MAX);
    $description = rg_popup_line((string)($input['description'] ?? ''), RG_POPUP_DESC_MAX);
    $coupon      = rg_popup_coupon((string)($input['coupon_code'] ?? ''));

    $ctaEnabled = !empty($input['cta_enabled']);
    $ctaText    = rg_popup_line((string)($input['cta_text'] ?? ''), RG_POPUP_CTA_MAX);
    $ctaUrlRaw  = trim((string)($input['cta_url'] ?? ''));
    $ctaUrl     = '';
    if ($ctaUrlRaw !== '') {
        $ctaUrl = rg_safe_url($ctaUrlRaw, 'popup_cta');
        if ($ctaUrl === '') {
            $errors['cta_url'] = 'That button link is not a normal web address. Use https://… or a page on this site.';
        }
    }
    if ($ctaEnabled && $ctaText === '') {
        $ctaText = 'Claim offer';
    }
    if ($ctaEnabled && $ctaUrl === '') {
        $errors['cta_url'] = $errors['cta_url'] ?? 'Add a destination for the button, or switch the button off.';
    }

    $trigger = strtolower(trim((string)($input['trigger_type'] ?? 'delay')));
    if (!array_key_exists($trigger, rg_popup_triggers())) $trigger = 'delay';
    $triggerValue = (int)($input['trigger_value'] ?? 3);
    $triggerValue = max(1, min(60, $triggerValue));

    $frequency = strtolower(trim((string)($input['frequency'] ?? 'session')));
    if (!array_key_exists($frequency, rg_popup_frequencies())) $frequency = 'session';

    $targets = rg_popup_targets((string)($input['targets'] ?? 'home'));

    $starts = rg_popup_date($input['starts_at'] ?? null, '00:00:00');
    $ends   = rg_popup_date($input['ends_at'] ?? null, '23:59:59');
    if ($starts !== null && $ends !== null && strtotime($ends) < strtotime($starts)) {
        $errors['ends_at'] = 'The end date is before the start date.';
    }

    $status = strtolower(trim((string)($input['status'] ?? 'draft')));
    if (!in_array($status, ['draft', 'active', 'paused'], true)) $status = 'draft';

    /* Publishing needs an image: a promotion with no artwork is not a popup. */
    $image = $removeImage ? '' : $newImage;
    if ($image === '' && !$removeImage && $id > 0) {
        $image = rg_popup_image_from_db($id);
    }
    if ($status === 'active' && $image === '') {
        $errors['image'] = 'Upload the popup image before publishing.';
    }

    if ($errors) {
        return ['ok' => false, 'id' => $id, 'errors' => $errors];
    }

    global $conn;

    try {
        if ($id > 0) {
            $stmt = $conn->prepare("UPDATE popups SET name = ?, status = ?, layout = ?, image = ?, heading = ?,
                description = ?, coupon_code = ?, cta_enabled = ?, cta_text = ?, cta_url = ?, cta_new_tab = ?,
                trigger_type = ?, trigger_value = ?, frequency = ?, targets = ?, starts_at = ?, ends_at = ?
                WHERE id = ?");
            $stmt->execute([
                $name, $status, $layout, $image, $heading, $description, $coupon,
                $ctaEnabled ? 1 : 0, $ctaText, $ctaUrl, !empty($input['cta_new_tab']) ? 1 : 0,
                $trigger, $triggerValue, $frequency, $targets, $starts, $ends, $id,
            ]);
            return ['ok' => true, 'id' => $id, 'errors' => []];
        }

        $stmt = $conn->prepare("INSERT INTO popups (name, status, layout, image, heading, description,
            coupon_code, cta_enabled, cta_text, cta_url, cta_new_tab, trigger_type, trigger_value,
            frequency, targets, starts_at, ends_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $name, $status, $layout, $image, $heading, $description, $coupon,
            $ctaEnabled ? 1 : 0, $ctaText, $ctaUrl, !empty($input['cta_new_tab']) ? 1 : 0,
            $trigger, $triggerValue, $frequency, $targets, $starts, $ends,
        ]);
        $newId = (int)$conn->lastInsertId();
        return ['ok' => true, 'id' => $newId, 'errors' => []];
    } catch (Exception $e) {
        error_log('popup save failed: ' . $e->getMessage());
        return ['ok' => false, 'id' => $id, 'errors' => ['form' => 'Could not save the campaign.']];
    }
}

/** The image currently stored on a campaign ('' when there is none). */
function rg_popup_image_from_db(int $id): string
{
    global $conn;
    try {
        $stmt = $conn->prepare("SELECT image FROM popups WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ? (string)($row['image'] ?? '') : '';
    } catch (Exception $e) {
        return '';
    }
}

/** Removes a stored image file, refusing anything outside assets/uploads. */
function rg_popup_delete_file(string $path): void
{
    if (preg_match('#^assets/uploads/[A-Za-z0-9._-]+$#', $path) !== 1) return;
    $absolute = __DIR__ . '/../' . $path;
    if (is_file($absolute)) @unlink($absolute);
}

function rg_popup_delete(int $id): bool
{
    global $conn;
    try {
        $image = rg_popup_image_from_db($id);
        $stmt = $conn->prepare("DELETE FROM popups WHERE id = ?");
        $stmt->execute([$id]);
        rg_popup_delete_file($image);
        return true;
    } catch (Exception $e) {
        error_log('popup delete failed: ' . $e->getMessage());
        return false;
    }
}

function rg_popup_set_status(int $id, string $status): bool
{
    global $conn;
    if (!in_array($status, ['draft', 'active', 'paused'], true)) return false;
    try {
        $stmt = $conn->prepare("UPDATE popups SET status = ? WHERE id = ?");
        $stmt->execute([$status, $id]);
        return true;
    } catch (Exception $e) {
        return false;
    }
}

/* ------------------------------------------------------------------- reads */

/** Every campaign, newest first, for the admin list. */
function rg_popup_all(): array
{
    global $conn;
    try {
        $rows = $conn->query("SELECT * FROM popups ORDER BY created_at DESC, id DESC")->fetchAll();
        return is_array($rows) ? $rows : [];
    } catch (Exception $e) {
        return [];
    }
}

function rg_popup_find(int $id): ?array
{
    global $conn;
    try {
        $stmt = $conn->prepare("SELECT * FROM popups WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    } catch (Exception $e) {
        return null;
    }
}

/** The counters on the admin dashboard. */
function rg_popup_stats(array $rows, ?int $now = null): array
{
    $stats = ['total' => 0, 'active' => 0, 'scheduled' => 0, 'expired' => 0, 'paused' => 0, 'draft' => 0,
              'impressions' => 0, 'clicks' => 0];
    foreach ($rows as $row) {
        $stats['total']++;
        $state = rg_popup_status($row, $now);
        if (isset($stats[$state])) $stats[$state]++;
        $stats['impressions'] += (int)($row['impressions'] ?? 0);
        $stats['clicks']      += (int)($row['clicks'] ?? 0);
    }
    return $stats;
}

/**
 * The one campaign to show on this page, or null.
 *
 * SQL decides what is live (status + date window + has an image); PHP then checks
 * the page targeting, so the two rules stay readable and testable.
 */
function rg_popup_active_for(string $page): ?array
{
    global $conn;
    if ($page === '') return null;

    try {
        $stmt = $conn->query("SELECT * FROM popups
            WHERE status = 'active'
              AND image <> ''
              AND (starts_at IS NULL OR starts_at <= NOW())
              AND (ends_at IS NULL OR ends_at >= NOW())
            ORDER BY updated_at DESC, id DESC");
        $rows = $stmt->fetchAll();
    } catch (Exception $e) {
        return null;
    }

    foreach ((array)$rows as $row) {
        /* The SQL above already filters on status and dates. It is repeated here
           on purpose: if a host serves a cached or hand-edited row, the page still
           refuses to show a campaign that is not live right now. */
        if (rg_popup_status($row) !== 'active') continue;
        if (!rg_popup_targets_match((string)($row['targets'] ?? ''), $page)) continue;
        if (rg_popup_image_url((string)($row['image'] ?? '')) === '') continue;
        return $row;
    }
    return null;
}

/* ------------------------------------------------------------------ render */

/**
 * Prints one popup: the dialog itself plus its configuration.
 *
 * `hidden` is in the markup, so an unopened popup can never flash on the page and
 * never blocks a click. The script decides whether and when to show it.
 */
function rg_popup_render(array $popup, string $page = ''): void
{
    $imageUrl = rg_popup_image_url((string)($popup['image'] ?? ''));
    if ($imageUrl === '') return;

    $layout      = (string)($popup['layout'] ?? 'image_text');
    $heading     = (string)($popup['heading'] ?? '');
    $description = (string)($popup['description'] ?? '');
    $coupon      = (string)($popup['coupon_code'] ?? '');
    $ctaEnabled  = (int)($popup['cta_enabled'] ?? 0) === 1;
    $ctaText     = (string)($popup['cta_text'] ?? '');
    $ctaUrl      = rg_safe_url((string)($popup['cta_url'] ?? ''), 'popup_cta');
    $ctaNewTab   = (int)($popup['cta_new_tab'] ?? 1) === 1;

    $hasBody  = in_array($layout, ['image_text', 'image_cta', 'announcement'], true)
                || $coupon !== '' || ($ctaEnabled && $ctaUrl !== '');
    $showText = in_array($layout, ['image_text', 'announcement'], true);
    $showCta  = $ctaEnabled && $ctaUrl !== '' && $ctaText !== '';

    $headingId = 'rgPopHeading';
    $descId    = 'rgPopDesc';
    ?>
<div class="rg-pop" id="rgPopup" hidden
     data-popup-id="<?= (int)$popup['id'] ?>"
     data-page="<?= e($page) ?>"
     data-trigger="<?= e((string)($popup['trigger_type'] ?? 'delay')) ?>"
     data-trigger-value="<?= (int)($popup['trigger_value'] ?? 3) ?>"
     data-frequency="<?= e((string)($popup['frequency'] ?? 'session')) ?>"
     data-coupon="<?= e($coupon) ?>"
     data-event-url="<?= e(url('popup_event.php')) ?>">
  <div class="rg-pop-backdrop" data-rg-pop-close="1"></div>

  <div class="rg-pop-card rg-pop-card--<?= e($layout) ?>"
       role="dialog" aria-modal="true"
       aria-labelledby="<?= $heading !== '' ? $headingId : '' ?>"
       <?= $heading === '' ? 'aria-label="Promotion"' : '' ?>
       <?= $description !== '' ? 'aria-describedby="' . $descId . '"' : '' ?>>

    <button class="rg-pop-close" type="button" data-rg-pop-close="1" aria-label="Close this offer">×</button>

    <figure class="rg-pop-media">
      <img src="<?= e($imageUrl) ?>" alt="<?= e($heading !== '' ? $heading : 'Promotion') ?>"
           loading="lazy" decoding="async">
    </figure>

    <?php if ($hasBody): ?>
    <div class="rg-pop-body">
      <?php if ($showText && $heading !== ''): ?>
      <h2 class="rg-pop-heading" id="<?= $headingId ?>"><?= e($heading) ?></h2>
      <?php endif; ?>
      <?php if ($showText && $description !== ''): ?>
      <p class="rg-pop-text" id="<?= $descId ?>"><?= e($description) ?></p>
      <?php endif; ?>

      <?php if ($coupon !== ''): ?>
      <div class="rg-pop-coupon">
        <span class="rg-pop-coupon-label">Coupon code</span>
        <div class="rg-pop-coupon-row">
          <code id="rgPopCoupon"><?= e($coupon) ?></code>
          <button class="rg-pop-copy" type="button" id="rgPopCopy" data-copy-target="rgPopCoupon">
            Copy code
          </button>
        </div>
        <span class="rg-pop-copied" id="rgPopCopied" role="status" aria-live="polite" hidden>Copied to your clipboard</span>
      </div>
      <?php endif; ?>

      <?php if ($showCta): ?>
      <a class="rg-pop-cta" id="rgPopCta"
         href="<?= e($ctaUrl) ?>"
         <?= $ctaNewTab ? 'target="_blank" rel="noopener noreferrer"' : '' ?>
         data-rg-pop-cta="1"><?= e($ctaText) ?></a>
      <?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
</div>
    <?php
}

/**
 * The campaign waiting for this page, looked up once per request.
 *
 * The head tag and the body both need the answer, and a page view must not cost
 * two queries. Cached by page name.
 */
function rg_popup_pending(string $page = ''): ?array
{
    static $cache = [];

    $page = $page !== '' ? $page : rg_popup_current_page();
    if (array_key_exists($page, $cache)) return $cache[$page];

    return $cache[$page] = rg_popup_active_for($page);
}

/**
 * The public pages call this once, after the body content.
 *
 * It prints nothing at all when no campaign targets this page — so an ordinary
 * visit to the homepage costs one indexed query and a few bytes.
 */
function print_rg_popup(string $page = ''): void
{
    $page = $page !== '' ? $page : rg_popup_current_page();
    $popup = rg_popup_pending($page);
    if (!$popup) return;

    rg_popup_render($popup, $page);
}

/**
 * The stylesheet + script tags, printed in the page head.
 *
 * Empty when nothing targets this page: a visitor who will not see a popup does
 * not download its CSS or its script either.
 */
function rg_popup_head(string $page = ''): string
{
    if (rg_popup_pending($page) === null) return '';

    return '<link rel="stylesheet" href="' . e(asset('css/popup.css')) . '">' . "\n"
         . '<script defer src="' . e(asset('js/popup.js')) . '"></script>';
}
